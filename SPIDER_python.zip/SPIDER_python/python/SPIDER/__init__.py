import os
from . import predict_seen
from . import predict_unseen
name = "SPIDER"
__all__=['predict_seen', 'predict_unseen', 'train_model']
